package com.example.test_gafova

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View.OnCreateContextMenuListener
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.material.bottomnavigation.BottomNavigationMenuView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         val getContent = registerForActivityResult(ActivityResultContracts.GetContent())
        {
                uri: Uri? -> ivObrazek.setVideoURI(uri)
        }
        getContent.launch("video/*")
        ivObrazek.setOnClickListener {
            var test:Boolean = true
            if (test==true)
            {
                ivObrazek.start()
                test = false

            }
            if (test==false){
                ivObrazek.pause()
                test = true
            }
        }

        ivPlay.setOnClickListener {
            ivObrazek.start()
        }
        ivClose.setOnClickListener {
            ivObrazek.pause()
        }
        bottomNavigationView2.setOnNavigationItemSelectedListener { item->
            when(item.itemId)
            {
                R.id.miClose -> finish()
            }
            return@setOnNavigationItemSelectedListener true
        }
    }

}

